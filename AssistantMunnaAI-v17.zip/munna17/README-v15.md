# Assistant Munna AI v15

v15 adds a natural-language-to-source-to-build pipeline foundation.

## Flow
1. User writes or speaks what app they want.
2. Android sends the request to the backend.
3. `/projects/generate` creates a real Android source project from the request.
4. `/projects/build` sends that project to the isolated build-worker path.
5. The task can be polled with `/tasks/:id` until `completed`, `failed`, or `blocked`.
6. A completed build exposes an APK artifact path for download by an authenticated client in a production deployment.

## Important
The repository contains the build pipeline, but it does not magically include a hosted compiler or AI provider. For real one-click APK generation, run the backend and an isolated worker with Android/Gradle tooling, and configure an AI provider if you want richer code generation than the built-in local generator.

## Backend
```bash
cd backend
npm start
```

Enable building only inside a sandbox/VM/container:
```bash
MUNNA_BUILD_ENABLED=1 npm start
```

Do not expose the worker directly to the public internet. Add authentication, quotas, signed artifact URLs, storage cleanup, and resource/time limits before production use.
