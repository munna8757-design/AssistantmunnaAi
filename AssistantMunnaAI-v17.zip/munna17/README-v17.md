# Assistant Munna AI v17

v17 is an Android APK-build-ready source package. It adds a cloud build workflow so the Android project can be compiled without Android Studio on the user's phone.

Important: this environment does not have the Android SDK/Gradle build toolchain installed, so a binary APK cannot be truthfully claimed as built here. The included GitHub Actions workflow performs the real Gradle compilation and uploads the resulting debug APK as an artifact.
