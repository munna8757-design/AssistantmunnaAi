# Assistant Munna AI v14

## One-click APK build workflow
Android UI now has **🚀 এক ক্লিকে APK Build**. It sends the user's app request to `POST /projects/build`, creates a task ID, polls status, and reports `completed`, `failed`, or `blocked`.

### Important
The API process does not execute arbitrary code. APK compilation is delegated to `backend/worker/build_worker.js`. For real builds, run that worker inside an isolated container/VM and set `MUNNA_BUILD_ENABLED=1`.

### Backend
```bash
cd backend
npm install
MUNNA_BUILD_ENABLED=1 node server.js
```
For production, do NOT run the worker with unrestricted host access. Use the supplied `backend/worker/Dockerfile` as the starting point for an isolated build environment.

### Android
Open `android/` in Android Studio and build/install the app. The emulator backend is `http://10.0.2.2:8787`. On a physical phone, change `BACKEND` in `MainActivity.java` to the backend server's LAN address.

### What works now
- One-click build request
- Task ID/status polling
- Build worker integration
- APK artifact path returned after a successful build
- Backend-disabled/worker-disabled state is reported honestly

### What is still needed for a full AI app factory
- Connect a real AI provider for code generation
- Generate project source from the user's natural-language specification
- Strong per-job sandbox isolation and resource limits
- Signing/keystore management
- Artifact download/authentication
- Image/video processing workers
