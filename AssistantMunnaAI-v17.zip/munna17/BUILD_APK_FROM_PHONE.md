# Build v17 APK from an Android phone

The source itself is not an APK. The included GitHub Actions workflow can compile it in the cloud without Android Studio on your phone.

1. Create/sign in to a GitHub account.
2. Create a new repository.
3. Upload the contents of this project (especially `android/` and `.github/`).
4. Open **Actions → Build Assistant Munna AI APK → Run workflow**.
5. Wait for the build to finish.
6. Open the completed workflow run and download the artifact `AssistantMunnaAI-v17-debug-apk`.
7. Extract the ZIP and install `app-debug.apk` on Android.

For a release APK suitable for distribution, a signing key and a secure secrets setup are required; do not put the keystore/password in the repository.
