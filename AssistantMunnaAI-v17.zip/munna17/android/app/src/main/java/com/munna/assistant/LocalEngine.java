package com.munna.assistant;

import java.util.*;
import org.json.*;

public final class LocalEngine {
  private LocalEngine() {}
  public static JSONObject plan(String message, String type) {
    JSONObject o=new JSONObject();
    try {
      o.put("mode","local-demo"); o.put("type",type); o.put("message",message);
      o.put("task_id",UUID.randomUUID().toString());
      if("software".equals(type)) {
        o.put("reply","Software project plan তৈরি হয়েছে। Backend build worker সংযুক্ত করলে APK/desktop artifact build করা যাবে।");
        o.put("steps",new JSONArray(Arrays.asList("Requirements parse","Project scaffold","Code generation","Sandbox build","Artifact export")));
      } else if("image".equals(type)) o.put("reply","Image task প্রস্তুত। একটি ছবি নির্বাচন করলে processing workflow চালানো যাবে।");
      else if("video".equals(type)) o.put("reply","Video task প্রস্তুত। Video file নির্বাচন করলে trim/edit workflow চালানো যাবে।");
      else if("file".equals(type)) o.put("reply","File/PDF task প্রস্তুত। File নির্বাচন করলে analysis workflow চালানো যাবে।");
      else o.put("reply","Local demo AI engine কাজটি বুঝেছে। Online AI provider যুক্ত করলে পূর্ণ AI response পাওয়া যাবে।");
      o.put("status","planned");
    } catch(Exception ignored) {}
    return o;
  }
}
