package com.munna.assistant;

import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public final class BackendClient {
    private BackendClient() {}
    public static void postJson(String baseUrl, String path, JSONObject payload, Callback cb) {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL(baseUrl.replaceAll("/$", "") + path);
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(8000); c.setReadTimeout(15000);
                c.setRequestProperty("Content-Type","application/json; charset=utf-8");
                c.setDoOutput(true);
                try(OutputStream os=c.getOutputStream()){ os.write(payload.toString().getBytes("UTF-8")); }
                int code=c.getResponseCode();
                InputStream in=code>=400?c.getErrorStream():c.getInputStream();
                BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));
                StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line);
                cb.done(code,b.toString());
            } catch(Exception e){ cb.error(e); } finally { if(c!=null)c.disconnect(); }
        }).start();
    }
    public static void getJson(String baseUrl, String path, Callback cb) {
        new Thread(() -> { HttpURLConnection c=null; try { URL u=new URL(baseUrl.replaceAll("/$","")+path); c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(5000); c.setReadTimeout(8000); int code=c.getResponseCode(); InputStream in=code>=400?c.getErrorStream():c.getInputStream(); BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8")); StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line); cb.done(code,b.toString()); } catch(Exception e){cb.error(e);} finally{if(c!=null)c.disconnect();} }).start();
    }

    public interface Callback { void done(int code,String body); void error(Exception e); }
}
