#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="${1:-android}"
if command -v docker >/dev/null 2>&1; then
  docker compose run --rm munna-backend bash -lc "cd /workspace/$PROJECT_DIR && gradle :app:assembleDebug --no-daemon"
elif command -v gradle >/dev/null 2>&1; then
  (cd "$PROJECT_DIR" && gradle :app:assembleDebug --no-daemon)
else
  echo "No local Android/Gradle toolchain found. Use .github/workflows/build-apk.yml (cloud build) or install Android SDK + Gradle." >&2
  exit 2
fi
APK="$PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"
if [[ -f "$APK" ]]; then echo "APK_READY=$APK"; else echo 'APK build finished but artifact was not found.'; exit 3; fi
