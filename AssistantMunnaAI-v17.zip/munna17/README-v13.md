# Assistant Munna AI v13

v13 adds a usable task lifecycle on top of the Android client and backend.

## New
- Task IDs and status polling (`queued` → `running` → `completed`/`failed`)
- Local planning fallback when no AI provider is configured
- OpenAI-compatible provider gateway via environment variables
- Software build workflow endpoint with sandbox-required artifact policy
- Android client polls backend task status
- API health endpoint reports provider configuration

## Run backend
```bash
cd backend
cp .env.example .env
# Set MUNNA_AI_PROVIDER_URL / MUNNA_AI_API_KEY / MUNNA_AI_MODEL if desired
node server.js
```

The backend intentionally does **not** execute arbitrary user code or build APKs inside the API process. A separate sandboxed worker is required for production builds.

## Android
Open `android/` in Android Studio. The default emulator backend is `http://10.0.2.2:8787`.
For a physical phone, change `BACKEND` in `MainActivity.java` to the computer/server's LAN address.
