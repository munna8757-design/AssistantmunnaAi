# Assistant Munna AI v12

v12 adds a local demo execution engine and task-planning flow to the Android client.

## New
- Local task planning when the backend is unavailable.
- Task history inside the Android app.
- Software Build Plan button.
- Online backend submission plus offline/local fallback.
- `/tasks/plan` backend endpoint.
- Corrected AndroidManifest XML structure.

## Important
This is still a development foundation. Real model inference, media processing, secure sandbox workers and APK signing/build services must be deployed separately.
