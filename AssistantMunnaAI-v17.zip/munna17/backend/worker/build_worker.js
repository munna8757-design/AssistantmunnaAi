// Isolated Android APK build worker. Prefer running this module in the supplied container.
const fs=require('fs'),path=require('path'),cp=require('child_process'),crypto=require('crypto');
const ROOT=path.resolve(__dirname,'../..');
const JOBS=path.join(ROOT,'backend','builds'); fs.mkdirSync(JOBS,{recursive:true});
function copyDir(src,dst){fs.mkdirSync(dst,{recursive:true});for(const e of fs.readdirSync(src,{withFileTypes:true})){if(['builds','.gradle'].includes(e.name))continue;const a=path.join(src,e.name),b=path.join(dst,e.name);e.isDirectory()?copyDir(a,b):fs.copyFileSync(a,b);}}
function build(spec={}){
 const id=crypto.randomUUID(),dir=path.join(JOBS,id); const template=spec.sourceDir;
 if(!template || !fs.existsSync(path.join(template,'settings.gradle'))) return Promise.resolve({id,status:'failed',error:'Invalid Android project: settings.gradle not found'});
 copyDir(template,dir); fs.writeFileSync(path.join(dir,'build-meta.json'),JSON.stringify({build_id:id,status:'running',created_at:new Date().toISOString(),project:spec.project||{}},null,2));
 return new Promise(resolve=>{
  const gradle=process.env.GRADLE_BIN||'gradle'; const args=[':app:assembleDebug','--no-daemon','--stacktrace']; let log='';
  const p=cp.spawn(gradle,args,{cwd:dir,env:{...process.env,GRADLE_OPTS:'-Dorg.gradle.jvmargs=-Xmx1536m'},shell:false});
  p.stdout.on('data',d=>{log+=d.toString();if(log.length>150000)log=log.slice(-150000)}); p.stderr.on('data',d=>{log+=d.toString();if(log.length>150000)log=log.slice(-150000)});
  p.on('error',e=>resolve({id,status:'failed',error:e.message,log}));
  p.on('close',code=>{const apk=path.join(dir,'app','build','outputs','apk','debug','app-debug.apk'); resolve(code===0&&fs.existsSync(apk)?{id,status:'completed',artifact:apk,log}:{id,status:'failed',error:`Gradle exited ${code}`,log});});
 });
}
module.exports={build};
