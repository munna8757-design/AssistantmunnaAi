# Architecture

Client -> API Gateway -> AI Core -> Tool Router -> Sandbox/Workers.

Safety boundaries: external actions require explicit authorization; code execution is sandboxed; secrets are never embedded in the client.
