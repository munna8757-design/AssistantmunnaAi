# Assistant Munna AI v16 — Real APK Build Worker

v16 adds a real Android/Gradle compilation path instead of only a build placeholder.

## One-click flow
1. User describes an Android app in the Assistant Munna AI client.
2. `/projects/generate` creates a complete Android Gradle project.
3. `/projects/build` queues the project for the isolated build worker.
4. The worker runs `gradle :app:assembleDebug` with Android SDK 35.
5. Poll `/tasks/:id` until `completed`.
6. Download `/artifacts/<build_id>/app-debug.apk`.

## Start the real builder
Requirements: Docker + Docker Compose.

```bash
docker compose up --build
```

Backend: `http://localhost:8787`

The supplied container installs Node 20, JDK 17, Gradle 8.10.2, Android command-line tools, platform 35 and build-tools 35.0.0.

## Direct local build
If Gradle and Android SDK are already installed:

```bash
./build-apk.sh android
```

## Security
Do not expose the build endpoint directly to the public internet. Before production, add authentication, per-user quotas, CPU/RAM/time limits, network egress controls, ephemeral workspaces, artifact signing, malware scanning and automatic cleanup.
